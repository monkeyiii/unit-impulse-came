# 欢迎使用pycharm
# 请在“哔”声后开始操作
# 模板开发时间:2022/8/20 9:12
import datetime
import GUI界面
i = datetime.datetime.now()


def yeartype(year):
    """
    判断是否为闰年
    :param :year: 年份变量 类型为 int
    :return: 返回 int值
    """
    return int(year%4 ==0 or (year%100 != 0 and year%400 == 0))


def birthgap(month, day):
    """
    计算下一个生日离现在还有多少天

    :param :month: 月份 变量类型为 int
    :param :day: 日期 变量类型为 int
    :return: int
    """
    monthlength = [0,31,28+yeartype(i.year),31,30,31,30,31,31,30,31,30,31]
    gap = monthlength[i.month] - i.day
    if month > i.month:
        for j in range(i.month+1, month):
            gap += monthlength[j]
        gap += day

    if month == i.month and day > i.day:
        gap = day-i.day

    if month < i.month or (month == i.month and day <= i.day):
        for k in range(i.month+1, 13):
            gap += monthlength[k]
        monthlength[2] = 28+yeartype(i.year+1)
        for m in range(1, month):
            gap += monthlength[m]
        gap += day
    return gap


#print(birthgap(8, 22))



