def daochuyunshi(yunshi):
    """
    导出运势到文件

    :param yunshi: str型 该星座本日运势
    :return: None
    """
    fw = open("D:\\aceshi\\resultq.txt", "w")
    # aceshi 为我为resultq.txt测试所用的文件夹
    fw.write(yunshi)
    fw.write("\n")
