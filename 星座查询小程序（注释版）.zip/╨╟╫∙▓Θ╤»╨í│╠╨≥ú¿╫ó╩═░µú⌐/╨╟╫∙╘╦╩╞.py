import requests
from bs4 import BeautifulSoup

def xingzuoyunshi(xing):
    """
    得到星座后查询该星座本日运势

    :param xing: str: 字符串，为星座的英文
    :return: str: 得到运势后将其作为字符串返回
    """
    (xingzuo, zuo) = xing
    yunshia= "https://www.d1xz.net/yunshi/today/Aries/"
    yunshiw= yunshia[:34] + xingzuo
    req = requests.get(url=yunshiw)
    req.encoding = "utf-8"
    html = req.text
    soup = BeautifulSoup(req.text, features="html.parser")
    company_items = soup.find_all("div", class_="txt")
    for company_item in company_items:
        dd = company_item.text.strip()
    return dd


