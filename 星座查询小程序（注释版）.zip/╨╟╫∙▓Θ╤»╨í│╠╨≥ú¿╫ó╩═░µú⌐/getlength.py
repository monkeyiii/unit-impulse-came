# 欢迎使用pycharm
# 请在“哔”声后开始操作
# 模板开发时间:2022/8/22 9:49
import datetime
i = datetime.datetime.now()


def yeartype(year):
    """
    判断是否为闰年

    :param year: 年份 类型为 int
    :return: 返回一个 int值
    """
    return int(year % 4 == 0 or (year % 100 != 0 and year % 400 == 0))


def getlength(year, month, day):
    """
    计算出生到现在有多少天
    :param year: 年份变量 类型为 int
    :param month: 月份 变量类型为 int
    :param day: 日期 变量类型为 int
    :return: 返回 int 值
    """
    monthlength = [0, 31, 28+yeartype(year), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    length = monthlength[month] - day
    if year == i.year:
        if month == i.month:
            length = i.day-day
        else:
            for j in range(month+1, i.month):
                 length += monthlength[j]
            length += i.day
    else:
        for n in range(month+1,13):
            length += monthlength[n]
        monthlength[2] = 28+yeartype(i.year)
        for k in range(year+1, i.year):
            length += 365+yeartype(k)
        for m in range(1, i.month):
            length += monthlength[m]
        length += i.day
    return length


print(getlength(2002, 2, 1))
