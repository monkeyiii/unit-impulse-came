import datetime

i = datetime.datetime.now()


class Birthday:
    """
    包含出生年月日，需传入3个int参数

    year:  int： 年份
    month:  int： 月份
    day:  int： 日期
    """
    def __init__(self, year, month, day):  # 构造方法
        """
        初始化界面，定义变量

        :param year: int: 年
        :param month: int: 月
        :param day: int: 日
        """
        self.year = year
        self.month = month
        self.day = day

    def say_birthday(self):
        """
        显示出生年月日

        :return: None
        """
        print(self.year, self.month, self.day)

    def get_year(self):
        """
        年份输入

        :return: int
        """
        return self.year

    def get_month(self):
        """
        月份输入

        :return: int
        """
        return self.month

    def get_day(self):
        """
        日期输入

        :return: int
        """
        return self.day

    def inquiry(self):   #
        """
        查询离下个生日差多远

        :return: None
        """
        a = 1

    def constellation(self):   # 查询星座
        """
        查询星座

        :return: None
        """
        c = 1

    def luck(self):   # 查询运势
        """
        查询运势

        :return: None
        """
        b = 1


s1 = Birthday(2002, 4, 30)
a = s1.year
print(a)
s1.say_birthday()

