def daochuyunshi(yunshi):
    fw = open("D:\\aceshi\\resultq.txt", "w")
    # aceshi 为我为resultq.txt测试所用的文件夹
    fw.write(yunshi)
    fw.write("\n")
